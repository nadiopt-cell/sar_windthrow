# Method Note — Bi-temporal Windthrow Detection with Sentinel-1

This plugin implements (with two documented simplifications) the rapid
windthrow detection method of:

> Rüetschi, M.; Small, D.; Waser, L.T. **Rapid Detection of Windthrows
> Using Sentinel-1 C-Band SAR Data.** *Remote Sensing* 2019, 11(2), 115.
> https://doi.org/10.3390/rs11020115

## 1. Detection chain

```
S1 VV/VH files (pre window)          S1 VV/VH files (post window)
        │                                   │
        ▼                                   ▼
 align to reference grid             align to reference grid
 (bilinear warp if needed)           (bilinear warp if needed)
        │                                   │
        ▼                                   ▼
 median composite per pol            median composite per pol
        │                                   │
        └───────────────┬───────────────────┘
                        ▼
     dVV = VV_post − VV_pre ;  dVH = VH_post − VH_pre      [dB]
                        ▼
              WI = dVV + dVH                               [dB]
                        ▼
        threshold: WI > mean(WI) + a      (adaptive, paper)
                   WI > fixed value       (optional)
                        ▼
        median filter (3×3, optional) → 8-connected objects
                        ▼
        remove objects < n pixels (paper: n = 27)
                        ▼
        WI raster (float32) + mask (uint8) + polygons (area_ha)
```

## 2. Why WI is positive over windthrow

After a storm the forest canopy is replaced by a chaotic layer of
uprooted / broken trunks and branches. Rüetschi et al. measured mean
differences of +0.5 dB (VV) and +0.97 dB (VH) inside reference
windthrows versus ≈ 0 / +0.3 dB over intact forest: the increased
surface roughness and the reduced canopy attenuation raise backscatter
in **both** polarisations. Summing the two differences doubles the
separation of damaged from intact pixels.

## 3. Parameters

| Parameter | Default | Paper reference |
|-----------|---------|-----------------|
| `a` (adaptive offset) | 2.9 dB | optimum of the 108-combination grid search (2.8–3.35 tested) |
| `n` (min object) | 27 px ≈ 0.27 ha | optimum n = 27 (20–30 tested); reference areas ≥ 0.5 ha |
| windows | 1–5 pre / 1–3 post scenes | 5 pre + up to 10 post acquisitions (~2–4 weeks) |
| polarisations | VV + VH | IW GRDH dual-pol |
| forest mask | optional | detections computed inside a forest mask |

Reported accuracies of the original method: PA 0.85–0.88, UA
0.65–0.81 (areas ≥ 0.5 ha, 10 m grid).

## 3b. Forest mask (v0.9 / v1.1)

Detections and the adaptive-threshold mean can be restricted to forest.
Three sources are built in:

* **GFW Hansen GFC — forest on the year before the event (v1.1, the
  retrospective mask of record).** From the storm year `Y` the mask is
  reconstructed as

  ```
  forest_candidate(Y) = treecover2000 >= tau
                        AND NOT (1 <= lossyear <= Y-2001)
  ```

  i.e. the forest as of the year preceding the event: GFC losses of
  2001..Y−1 are excluded, the loss of the event year (the windthrow
  itself) is kept in the candidates.  A second `background` variant
  additionally removes event-year losses:

  ```
  forest_background(Y) = treecover2000 >= tau
                         AND NOT (1 <= lossyear <= Y-2000)
  ```

  («пиксели с потерей в год события из фона исключаются, но из
  маски-кандидата не убираются» — отчёт изд.8, разд. 9).  Defaults:
  `tau = 30 %`, the boolean candidate raster is averaged onto the
  reference grid and a target pixel is forest when the forest fraction
  ≥ 0.5 (the validated 30 m → 80 m rescore settings); a tau grid of
  20/30/50 % showed robust conclusions.  Layers (`treecover2000`,
  `lossyear`) of Hansen GFC-2024-v1.12 are read through `/vsicurl/`
  window by window — only the AOI is transferred (no auth needed).
  Files written: `<base>_forest_gfc<Y>.tif` (candidates; both WI and
  Coherence DiD modes) and `<base>_forestbg_gfc<Y>.tif` (background;
  Coherence DiD only).  Caveat: GFC is annual — intra-year pre-storm
  logging is not resolvable (the ID654 lesson), and losses after the
  product year are unknown.
* **ESA WorldCover 10 m** (`esa-worldcover` on Planetary Computer,
  epochs 2020 / 2021): Tree-cover class (10) is warped onto the radar
  grid (nearest), cleaned with a 3×3 majority filter and written as
  `<base>_forest_wc<year>.tif`. The STAC search, SAS signing and
  windowed COG reading (`/vsicurl/`) reuse the plugin's PC client —
  no local land-cover download is required.  Single-epoch: acceptable
  for near-real-time use only.
* **User file** — any raster (values > 0) or vector (polygons).

The forest mask is intersected with the analysis mask; when no separate
background mask is given, offsets and the mean WI are computed over the
forest sample (paper behaviour). In the Coherence DiD mode the two GFC
masks split responsibilities: the candidate mask restricts the
detection area, the background mask restricts only the statistics
sample (`background_mask_path` of
`CoherenceDeltaDetector.detect_file`).

Validation (report ed.8 §9, 12 events of 2015–2017): the GFC@Y
background shrinks 28–53 % versus the unmasked baseline; mean AUC is
statistically unchanged (0.620 → 0.618) — the mask's value is correct
forest-vs-forest background semantics, not metric inflation.  The
single-epoch WorldCover-2021 mask, in contrast, is a "mask from the
future": it left ZERO background pixels around the 30.07.2017 squall
ID655 (regrowth reclassified as shrub) and broke the method.  Rule of
thumb: retrospective events 2001–2024 → GFC@Y; monitoring of current
dates → WorldCover.

Historic note — v0.9 validation on event ID666 (squall 30.07.2017,
~950 ha; thresholds held identical to the baseline run): PA unchanged
(reference coverage 98–100 %), UA +13–15 % relative, false-alarm area
−19…−40 % depending on the variant. Remaining false positives are
small forest-internal disturbances — increase `n` or switch index for
those.

### 3.1 Background normalization (v0.8, not in the paper)

`normalize_background=True` (default) adds a weather-shift guard:
per polarisation the offset

```
offset_pol = median(post_dB − pre_dB)   inside the background sample
```

is subtracted from the post image before differencing. The sample is
the `background_mask_path` raster/vector when given (recommended: a
forest sample EXCLUDING the windthrow itself, e.g. a 3 km buffer around
the event minus the damaged polygons), else the analysis mask, else
the whole scene. The adaptive-threshold mean WI uses the same sample.
This protects the detection against the classic failure mode where a
wet-soil/rain event between acquisitions raises the whole post image
by ~+1 dB and floods the map with false alarms; the per-polarisation
offsets are reported in the diagnostics (`offset_db`,
`*_wi_norm.tif`).

## 4. Documented simplifications

1. **Median compositing instead of LRW.** The paper merges
   acquisitions by local resolution weighting (weights ∝ 1 / local
   illuminated area). The plugin computes the pixel-wise median, which
   is robust against speckle and date-to-date variation but does not
   exploit the per-acquisition local resolution. In flat-to-moderate
   terrain the difference is small.
2. **Raw DN → dB instead of full radiometric calibration.** PC GRD
   assets are raw DN; the plugin converts with 10·log10. For
   change detection the (nearly constant) calibration factor cancels in
   the differencing; a small S1A/S1B cross-sensor offset
   (~0.1–0.3 dB) may remain. Use the PC **RTC** collection
   (calibrated γ⁰) when quantitative rigour matters — it also matches
   the γ⁰ domain of the paper.

## 5. Sign convention (important!)

Windthrow = **increase** → WI positive. If a run flags water bodies
after windy dates (wind-roughened surface) or agricultural fields
(harvest / ploughing), those are expected confusion sources — restrict
detection with a forest mask and/or raise `a` / `n`.

## 6. L-band decline mode (v1.0)

Sources: ALOS PALSAR / PALSAR-2 annual mosaics (HH/HV, delivered as
DN on Planetary Computer; auto-converted to dB like the C-band chain —
the calibration constant cancels in the differencing).

Physics (Tanase et al. 2018): L-band waves penetrate the canopy and
interact with trunks and large branches. A flattened stand LOSES
volume scattering, so the backscatter DECLINES over windthrow — the
opposite sign of the C-band WI. The plugin reuses the complete
WindthrowDetector chain and flips the difference sign:

    LDI = (HH_pre − HH_post) + (HV_pre − HV_post)   [dB]

positive over windthrow, exactly like WI. Everything else — median
composites, background normalization, adaptive threshold
(median/mean of LDI + a), minimum-object cleanup, forest mask,
polygonisation — behaves identically; the index raster is named
`<base>_ldi.tif` (`<base>_ldi_norm.tif` with normalization).

Validation (project sessions 02.09.2026, ALOS annual mosaics, two
European Russia events against the Shikhov et al. 2020 database):

| Event | Channel | invAUC |
|---|---|---|
| ID666 (squall line, 950 ha, 30.07.2017) | dHH | 0.870 |
| ID666 | dHV | 0.732 |
| ID694 (tornado, 161 ha, 19.09.2017) | dHV | 0.905 |
| ID694 | dHH | 0.733–0.805 |

Practical notes: annual mosaics mean one pre / one post epoch (12
months apart), so the adaptive offset `a` should start near 1.5–2.0 dB
(the GUI default), not the C-band 2.9. A forest mask is strongly
recommended: regrowth fields and agricultural changes also decline in
L-band. The GUI method selector defaults to both HH+HV; a single
channel can be requested explicitly (`polarizations=["hv"]`).

## 7. Coherence DiD mode (v1.0; burst products since v1.2)

Sources: two ASF HyP3 InSAR products of the SAME footprint — a
pre/post pair bracketing the damage and a control pair from outside
the damage window. Since v1.2 two product families are accepted:

* **INSAR-GAMMA full frames** (GAMMA processor, 80 m, 20×4 looks,
  UTM) — the validated baseline of the project (`S1AB_<dates>..._INT80_G_...`);
* **Burst InSAR pairs** (ISCE processor, `INSAR_ISCE_BURST` /
  `INSAR_ISCE_MULTI_BURST`: `S1_<track>_<burst IDs>_IW_<dates>_<pol>_INT<sp>_<id>`)
  — pixel spacing 20 m (5×1), **40 m (10×2 — the «бёрст-пары 40 м»
  option of report ed.9, 1 credit per 1–4 pairs)** or 80 m (20×4);
  a burst footprint (~50–150 km²) matches narrow tornado tracks that
  a full frame maps at a 1–2 % object-size fraction.

The plugin accepts unpacked product folders, original `.zip` archives
or direct `*_corr.tif` paths; the control layer is warped onto the
pre/post grid when needed (nearest for water masks, bilinear for
coherence).

**DiD pairing validation (v1.2).** The granule names of both products
are parsed; the DiD is rejected up front when

* a GAMMA frame is mixed with a burst product (incompatible
  footprints and look conventions);
* two burst products carry DIFFERENT relative burst IDs, tracks or
  polarizations (the coherence rasters of different bursts only
  overlap along burst borders — a mismatched DiD degrades to edge
  noise); order the control pair in Vertex for the SAME burst.

A different pixel spacing on the two sides (e.g. 40 m pre/post vs
80 m control) is allowed but warned about — resampling makes the dcoh
statistics noisy. Unrecognised (custom-renamed) products skip the
validation.

Metric (project step12b, 03.09.2026):

    dcoh = coh(control) − coh(prepost)

positive over windthrow: the damage-window pair decorrelates where
the canopy was disturbed, while the control pair tracks the
background level. The difference cancels static low-coherence
anomalies (harvests, wet ground) and seasonal drift. Validated
against the Shikhov reference:

| Event | AUC | excess median | TPR@FPR5% |
|---|---|---|---|
| ID694 (tornado, 161 ha) | **0.908** | +0.308 | 0.55 |
| ID666 (squall line, 950 ha) | 0.671 | +0.140 | 0.14 |

ID666 is confounded by storm-wide decorrelation of the July control
pair (its own background is storm-damaged); a pre-pre control pair is
the planned fix. Despite that, the DiD AUC (0.671) beats a naive
single-pair score on the same data once the contaminated background
is excluded.

Implementation notes baked into the plugin:

* **Adaptive threshold on the background MEDIAN** (not the mean):
  HyP3 scenes with seasonal drift shift the whole dcoh background
  (ID694 autumn freeze-up: +0.33 offset). The median stays at the
  background level; the mean would flag a third of the frame.
* Default offset `a = 0.25` ≈ false-alarm rate 8 % (ID694) / 14 %
  (ID666); 0.10 floods drifted scenes. Youden-optimal thresholds
  from the validation: 0.51 (ID694) / 0.27 (ID666).
* Default `min_pixels = 6`: one 80 m pixel covers 0.64 ha, so the
  10-m `n = 27` default would equal 17 ha — 27× the paper optimum.
  At the 40 m posting of 10×2-look Burst InSAR one pixel is 0.16 ha:
  scale `min_pixels` up to ≈ 20–25 px to keep the validated ≈ 3.8 ha
  object size (the plugin logs a hint when the effective object area
  drops below 2 ha).
* **Sane water-mask heuristic (v1.2 semantics)**: a product water
  mask claiming more than 50 % of the frame is corrupt (HyP3 product
  5748 marked 99.6 % water) and is ignored with a warning.
  **Convention fix:** per the ASF product guides (GAMMA and ISCE
  alike) water masks encode **1 = land, 0 = water**. v1.0/v1.1 read
  them inverted (kept mask > 0, i.e. WATER) — on real products the
  masks were rejected as "corrupt" (the > 0 share was actually land)
  and, on water-dominant frames, detections were clipped to water
  bodies. Since v1.2 the mask is converted to a keep-land layer
  (255 = land) with a nearest-neighbour warp and the water share is
  counted as the share of 0 pixels; legacy 1 = water products can be
  consumed via `sane_water_mask(..., water_value=1)`.
* Registered no-data and non-physical coherence values (±9999 warp
  fills, the products' own 0-nodata edges) are excluded from the
  statistics.
* Without a control pair the score degrades to `1 − coherence` of
  the pre/post pair (static decorrelation) and the plugin warns —
  that score is NOT robust against harvests and seasonal anomalies.

## 7b. Forest safeguard «вне_леса@Y» (v1.2.2)

A zone that was NOT forest before the storm cannot produce a DiD
windthrow signal: the article's ID654 lesson (a polygon logged inside
the year kept the damage-window pair coherent at 0.635 — a bare-ground
signature — while every scoring by modern vegetation maps still said
"forest"; the event ended as a degenerate point with AUC 0.051 and an
inverted excess). Since v1.2.2 the detector computes two checks from
data the run already loads and reports them in
`result["forest_safeguard"]`:

1. **Mean pre/post coherence inside the zone** — the zone is the
   analysis mask («внутри полигона»), else the background forest
   mask, else the whole scene. Above **0.6** it is the bare-ground /
   non-forest signature (ID654: 0.635) and the zone is flagged.
2. **Forest share of the scene** — taken from the background
   clean-forest@Y mask when available (the GFC@Y workflow builds it),
   else from the analysis mask. Below **0.3** the zone is outside the
   applicability limit («при доле леса GFC@Y ниже 0,3 плагин
   выставляет флаг вне_леса@Y»).

The run is NOT aborted — the flag is logged as a warning, carried in
the result dict (`flagged`, `flags`, `reasons`, `zone`,
`coh_prepost_mean`, `forest_share`) and shown in the GUI result box.
Interpretation caveats:

* a scene-wide zone without any mask dilutes the coherence check —
  an agricultural region flags correctly (nothing forest to detect),
  a mixed scene may not;
* the share check assumes the mask IS a forest map (GFC@Y or
  WorldCover — the GUI workflow guarantees this); a custom AOI mask
  only measures its own coverage, so a small AOI triggers the share
  flag even over healthy forest — read `zone` and `forest_share`
  before acting on the flag;
* thresholds are the article's numbers, not tuned: 0.6 coherence,
  0.3 forest share.

## 8. References

- Rüetschi, Small, Waser (2019), *Remote Sensing* 11(2):115.
- Tanase, Santoro, Wegmüller, de la Riva, Pérez-Cabello (2018),
  *Remote Sensing of Environment* 209:700–711 — L-band windthrow
  physics (decline sign convention of the v1.0 L-band mode).
- Small (2011), RTC γ⁰ methodology, *IEEE TGRS* 49(10):3799–3806.
- Shikhov, Chernokulsky, Azhigov, Semakina (2020), *Earth Syst. Sci.
  Data* 12:3489–3513 — windthrow event database for European Russia
  1986–2017 (validation source, see TESTING_PLAN.md).
- Shikhov, Abdullin, Semakina (2020), *Геодезия и картография*
  № 4, 19–30 — forest susceptibility mapping for the Ural region.
- ASF HyP3 documentation — INSAR-GAMMA product specification and
  credit accounting (https://hyp3-docs.asf.alaska.edu);
  Sentinel-1 Burst InSAR Product Guide (naming `INSAR_ISCE_BURST`,
  20/40/80 m postings, water-mask encoding 1 = land / 0 = water) —
  the source of the v1.2 burst support and water-mask fix
  (https://hyp3-docs.asf.alaska.edu/guides/burst_insar_product_guide).
